# VBS_SCIENCE_CHINA
materials for SCIENCE_CHINA Paper

execute: xelatex sciscn2.tex
